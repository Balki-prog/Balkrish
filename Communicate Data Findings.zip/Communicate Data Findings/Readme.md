<h1><b>Loan Characteristic on Borower APR</b></h1>
<h2><b> by Balakrishnan</b></h2>
<h3><b>Dataset</b></h3>
<p1>This Dataset has 113,197 loans and each loan has information which is about Borrower APR,status,debt,borrowed amount etc. Variables which contains missing values were removed to make this dataset is accurate. Outliers are also removed to provide more reliable data. This will lead to further investigation that could influence borrower APR and what loans take by what type of Borrowers.</p1>
<p2> The Dataset can be downladed here</p2>
<h2><b>Summary of Findings</b></h2>
<p3> After Analysing each variable in this dataset. Borrower Score, rating, available bank card credit and creditscore were found to be negatively correlated to Borrower APR. Moreover, as per this dataset borrower Scores gave the strongest negative relationship with borrower APR</p3>
<p4>Borrowers with different rating are also analysed. It gives the result the borrower with lower rating received higher APR percentage, and borrower with high rating received lower APR percentage. This discrete among differentiate groups of people in terms of APR received based on their rating scores</p4>
<h3><b>Key Insighs for Presentation</b></h3>
<p4> First, histrogram plot has created to visualize the distribution on Borrower APR percentage. After exploring all variables which is related to BorrowerAPR. ProsperScore has the strongest relationship with Borrower APR(negatively correleted). 
Scatter Plot and Heatma were also created to know the deep insights about ProsperScore and BorrowerAPR were negatively correlated. The third plot created multiple scatter plots(Borrower APR vs ProsperScore) on different letter ratings. The plots showed the lowest ratings of borrower received the higher APR percentage and borrower with highest rating received the lowest APR percentage </p4>